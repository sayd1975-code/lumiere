# Lumière — zestaw zdjęć do portfolio (AI, 18 sztuk)

Spójna sesja wizualna w palecie strony: głęboki granat + ciepły bursztyn.
Wszystkie pliki: JPG, 1024×768, ok. 190–340 kB. Proporcje slotów (4:3, 4:5, 8:5, kwadrat)
wytnie automatycznie CSS przez `object-fit: cover` — łatka CSS jest przygotowana.

## Jak wgrać (GitHub, bez terminala)

1. Otwórz https://github.com/sayd1975-code/lumiere/upload/main
2. W polu ścieżki (nad listą plików) dopisz `img/` — GitHub utworzy folder.
3. Przeciągnij wszystkie 18 plików .jpg (README zostaw).
4. Commit message np.: `img: zestaw zdjęć AI do portfolio (18 plików)`.
5. Napisz Vibe „gotowe" — zostaną wgrane łatki HTML/CSS/SW podpinające zdjęcia.

## Mapowanie: plik → miejsce na stronie

### index.html
| Plik | Slot |
|---|---|
| hero-index.jpg | Hero (wizualizacja salonu) |
| svc-kosmetologia.jpg | Kafel „Kosmetologia twarzy" |
| svc-rzesy-brwi.jpg | Kafel „Rzęsy i brwi" |
| svc-makijaz.jpg | Kafel „Makijaż" |
| split-index.jpg | Sekcja „O studiach" |

### o-nas.html
| Plik | Slot |
|---|---|
| split-historia.jpg | „Nasza historia" |
| team-marta.jpg | Marta Nowak — kosmetolog, właścicielka |
| team-karolina.jpg | Karolina Lis — stylistka rzęs i brwi |
| team-anna.jpg | Anna Zielińska — make-up artistka |

### galeria.html (kolejność = kolejność na stronie)
| Plik | Podpis kafla |
|---|---|
| gal1-wnetrze.jpg | Wnętrze studia — strefa oczekiwania (szeroki) |
| gal2-oczyszczanie.jpg | Oczyszczanie twarzy — efekt po serii 3 zabiegów |
| gal3-rzesy.jpg | Rzęsy 1:1 — efekt naturalny |
| gal4-makijaz-wieczorowy.jpg | Makijaż wieczorowy — paleta różu i nudi |
| gal5-laminat.jpg | Laminat brwi — utrwalony kształt |
| gal6-gabinet.jpg | Gabinet kosmetologiczny — fototerapia LED (szeroki) |
| gal7-slubny.jpg | Makijaż ślubny — wersja naturalna, trwała |
| gal8-detale.jpg | Detale studia — strefa makijażu |
| gal9-manicure.jpg | Manicure hybrydowa — kolekcja różowa |

## Uwagi
- Zdjęcia AI — do projektu pokazowego w pełni wystarczają; przy zleceniu klienckim podmienisz je na autentyczne.
- Przy tym rozmiarze JPG jest OK; docelowo można przekonwertować do .webp (~100 kB/szt.).
